# Jarvis v1.0.0 — Current Status

## Completed in this package
- Brain Core with chat / remember / recall / action routing.
- OpenAI-compatible HTTPS provider with API key kept out of source.
- Android Keystore AES-GCM storage for API credentials and local memory.
- Security allow-list and explicit confirmation for dialing.
- Bengali voice input (`bn-IN`) and Android TTS.
- Runtime microphone permission.
- Cleartext HTTP disabled and app backup disabled.
- Chat history is now passed to the AI provider (last 12 messages).
- UI loading state and clearer provider-configuration feedback.
- Added JVM unit tests for action parsing and SecurityGate behavior.
- Hardened AI endpoint validation: HTTPS only, valid host required, embedded credentials rejected.
- API-key entry is visually masked in the Security screen.
- Added `tools/build_release.sh` to run validation, tests and APK builds.

## Still required for a real V1.0 release
1. Run the included GitHub Actions Android build or use Android Studio with Android SDK 35 + Gradle 8.11.1.
2. A real HTTPS OpenAI-compatible endpoint and model name.
3. A real device test: microphone, Bengali recognition, TTS, memory, AI, intents and dial confirmation.
4. Release signing keystore and signed APK/AAB if distributing outside a development install.

## Important
This environment can inspect and modify the source package, but it does not have the Android SDK/Gradle toolchain or a physical Android device. Therefore this package includes an automated build path, but it is **not an honestly claimed tested APK**.
