# Jarvis Final Release Checklist

## Build
- Android Studio/Gradle with Android SDK 35 installed.
- `local.properties` must contain `JARVIS_AI_ENDPOINT` and `JARVIS_AI_MODEL` only.
- Do not put API keys in source control, Gradle files, or `local.properties`.
- Provision the API key into Jarvis's Android Keystore-backed credential store on the device.

## Security
- Cleartext HTTP is disabled.
- AI endpoint must be HTTPS at runtime.
- API key is encrypted with Android Keystore AES-GCM.
- High-impact dialing requires explicit confirmation and only opens the dialer.
- Runtime microphone permission is requested only when voice input is used.
- App backup is disabled.

## Device test
1. Install debug/release APK on a physical Android 8.0+ device.
2. Test text chat with no API key: app remains usable in demo mode.
3. Test API provider with a test key and HTTPS endpoint.
4. Deny microphone permission: app must continue without voice input.
5. Test Settings/Browser/Calculator actions.
6. Test dialing: verify confirmation is required and only the dialer opens.
7. Reboot the device and verify the encrypted API key can still be read.
8. Verify no secret appears in logcat or packaged resources.

This checklist is a release gate; this environment has not performed the physical-device steps.
