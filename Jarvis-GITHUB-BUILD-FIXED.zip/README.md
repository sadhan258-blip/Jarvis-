# Jarvis Final v1.0

A privacy-first Android assistant foundation with Brain Core, local encrypted memory, voice I/O, guarded Android actions, and an OpenAI-compatible AI provider.

## What is included
- Brain Core: chat, remember, recall, action intent routing.
- Encrypted local memory: AES-GCM with an Android Keystore key.
- Encrypted API credential: AES-GCM with a separate Android Keystore key.
- In-app Security screen to save/replace/clear the API key without displaying the stored value.
- HTTPS-only AI provider and Android cleartext traffic disabled.
- SecurityGate allow-list for Android actions.
- Dial action requires explicit confirmation and opens the system dialer; it does not place calls automatically.
- Guarded phone actions: web search, maps, camera, alarms, Wi-Fi settings, Bluetooth settings, calculator, browser, system settings, and common installed apps (YouTube/WhatsApp/Telegram/Gmail).
- Runtime microphone permission before speech recognition.
- Bengali speech recognition (`bn-IN`) and Android TTS.
- App backup disabled.

## Phone action examples

Jarvis can route commands such as `সার্চ ...`, `মানচিত্র ...`, `ক্যামেরা খোলো`, `অ্যালার্ম খোলো`, `WiFi settings`, `Bluetooth settings`, `ক্যালকুলেটর`, `YouTube খুলে দাও`, `WhatsApp খুলে দাও`, and `কল +91...`. Calling always opens the system dialer and requires an explicit confirmation phrase. Availability depends on the apps and capabilities installed on the phone.

## Configure the AI provider
Copy `local.properties.example` to `local.properties` and set:

- `JARVIS_AI_ENDPOINT` to an HTTPS OpenAI-compatible chat-completions endpoint.
- `JARVIS_AI_MODEL` to the model name supported by that endpoint.

Do not put an API key in `local.properties`. Enter the API key in Jarvis > Security. It is encrypted locally with Android Keystore.

## Build
Open the project in a current Android Studio installation with Android SDK 35 and let Gradle sync. Then build/install the debug APK. A GitHub Actions workflow is included to build the debug APK on a clean runner with Java 21, Android SDK 35 and Gradle 8.11.1. See `BUILD_ON_GITHUB.md`. This environment itself does not contain the Android/Gradle toolchain, so no APK is falsely claimed as locally built here.

## Device validation checklist
1. Install on a physical Android 8+ device.
2. Grant microphone permission and test Bengali speech recognition.
3. Test TTS output.
4. Configure an HTTPS AI endpoint and API key; verify a chat response.
5. Restart the app; verify encrypted API key and memory remain available.
6. Clear app data; verify the encrypted API key and memory are gone.
7. Test Settings, Browser and Calculator actions.
8. Test dial confirmation; verify Jarvis only opens the dialer and never places the call automatically.
9. Verify an HTTP AI endpoint is rejected.
10. Check behavior on the target OEM/device because speech recognition and intent handling can vary.

## Automated build path

`.github/workflows/android-build.yml` installs the required Android SDK/build tools, runs source validation and JVM tests, builds the debug APK, and uploads the APK as a workflow artifact.

## Validation status
This package has received source-level security/integrity checks in the preparation environment. It has **not** been represented as physically tested on a real Android device, and no claim of a successful APK build is made here because Android SDK/Gradle are unavailable in that environment.

## One-command release build
After opening/configuring the project with Android SDK 35:

```bash
./tools/build_release.sh
```

The script runs source validation, JVM unit tests, debug APK build, and release APK build.
