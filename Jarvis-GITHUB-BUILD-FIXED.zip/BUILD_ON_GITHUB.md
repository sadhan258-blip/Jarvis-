# Build Jarvis APK on GitHub

The repository is designed to build on GitHub Actions without a Gradle wrapper and without storing any API key in GitHub.

## Automatic build

Any push starts `.github/workflows/main.yml`. The workflow installs JDK 21, Gradle 8.11.1 and Android SDK 35, runs validation and unit tests, then builds:

`app/build/outputs/apk/debug/app-debug.apk`

The APK is uploaded to the workflow as the **Jarvis-APK** artifact.

## Important

The first GitHub build uses empty AI endpoint/model values, so the installed app starts in local Demo mode. No secret is embedded in the APK source. A compatible HTTPS AI endpoint and API key can be configured later.
