#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ -z "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" ]]; then
  echo "ERROR: Android SDK is not configured. Set ANDROID_SDK_ROOT/ANDROID_HOME or open this project in Android Studio."
  exit 2
fi
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME}}"
[[ -d "$SDK_ROOT/platforms/android-35" ]] || { echo "ERROR: Android SDK Platform 35 is missing. Run ./tools/setup_android_sdk.sh"; exit 2; }
[[ -d "$SDK_ROOT/build-tools/35.0.0" ]] || { echo "ERROR: Android Build Tools 35.0.0 are missing. Run ./tools/setup_android_sdk.sh"; exit 2; }
if [[ -x ./gradlew ]]; then GRADLE=./gradlew
elif command -v gradle >/dev/null 2>&1; then GRADLE=gradle
else
  echo "ERROR: Gradle is not installed. Open this project in Android Studio or install Gradle 8.x."
  exit 2
fi
./tools/validate_release.sh
"$GRADLE" :app:testDebugUnitTest :app:assembleDebug :app:assembleRelease
