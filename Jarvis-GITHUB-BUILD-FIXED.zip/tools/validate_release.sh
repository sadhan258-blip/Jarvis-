#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail(){ echo "FAIL: $1"; exit 1; }
grep -q 'android:usesCleartextTraffic="false"' "$ROOT/app/src/main/AndroidManifest.xml" || fail 'cleartext traffic is not disabled'
grep -q 'networkSecurityConfig' "$ROOT/app/src/main/AndroidManifest.xml" || fail 'network security config missing'
grep -q 'allowBackup="false"' "$ROOT/app/src/main/AndroidManifest.xml" || fail 'backup protection missing'
grep -RInE 'https?://[^/]' "$ROOT/app/src/main/java" | grep -v 'https://' && fail 'insecure http endpoint found' || true
grep -RInE '(sk-[A-Za-z0-9]{20,}|AIza[A-Za-z0-9_-]{20,}|Bearer[[:space:]]+[A-Za-z0-9._-]{20,})' "$ROOT/app/src/main" && fail 'possible hard-coded credential found' || true
grep -q 'AndroidKeyStore' "$ROOT/app/src/main/java/com/jarvis/assistant/core/SecureCredentialStore.kt" || fail 'credential keystore missing'
grep -q 'AndroidKeyStore' "$ROOT/app/src/main/java/com/jarvis/assistant/core/MemoryStore.kt" || fail 'memory keystore missing'
grep -q 'requiresConfirmation' "$ROOT/app/src/main/java/com/jarvis/assistant/core/SecurityGate.kt" || fail 'action confirmation gate missing'

grep -q 'DeviceBinding' "$ROOT/app/src/main/java/com/jarvis/assistant/core/DeviceBinding.kt" || fail 'device binding component missing'
grep -q 'startsWith(\"https://\")' "$ROOT/app/src/main/java/com/jarvis/assistant/brain/AiProviderFactory.kt" || fail 'AI provider HTTPS gate missing'

grep -q 'ACTION_DIAL' "$ROOT/app/src/main/java/com/jarvis/assistant/action/AndroidActionExecutor.kt" || fail 'dial action missing'
grep -q 'নিশ্চিত করে' "$ROOT/app/src/main/java/com/jarvis/assistant/action/ActionParser.kt" || fail 'confirmation parser missing'
echo 'PASS: Jarvis release source validation'
