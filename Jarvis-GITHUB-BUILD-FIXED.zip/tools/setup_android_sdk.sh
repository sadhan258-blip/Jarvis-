#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK_ROOT" ]]; then
  echo "ERROR: Android SDK not found. Set ANDROID_SDK_ROOT or ANDROID_HOME."
  echo "Android Studio can install it via Tools > SDK Manager."
  exit 2
fi
SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
if [[ ! -x "$SDKMANAGER" ]]; then
  SDKMANAGER="$SDK_ROOT/cmdline-tools/bin/sdkmanager"
fi
if [[ ! -x "$SDKMANAGER" ]]; then
  echo "ERROR: sdkmanager not found under $SDK_ROOT/cmdline-tools."
  exit 2
fi
"$SDKMANAGER" --licenses >/dev/null || true
"$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
echo "PASS: Android SDK 35 build requirements installed/available at $SDK_ROOT"
