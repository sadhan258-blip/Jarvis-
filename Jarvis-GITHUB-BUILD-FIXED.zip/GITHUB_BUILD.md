# Jarvis — GitHub APK Build

## Important
Upload the **contents of this ZIP** into the root of a GitHub repository. Do not upload the ZIP file itself as the project.

The repository must show these at its top level:
- `.github/workflows/main.yml`
- `settings.gradle.kts`
- `build.gradle.kts`
- `app/`
- `gradle.properties`

## Build
1. Open the repository on GitHub.
2. Open **Actions**.
3. Select **Build Jarvis APK**.
4. Tap **Run workflow** (or push/commit any project file; the workflow also runs automatically on push).
5. Wait for the green check.
6. Open the completed workflow run.
7. In **Artifacts**, download **Jarvis-APK**.
8. Inside it, use `app-debug.apk` to install Jarvis on Android.

No API key is required to compile the APK. Without an API endpoint/model and key, the installed app safely runs in Demo mode.
