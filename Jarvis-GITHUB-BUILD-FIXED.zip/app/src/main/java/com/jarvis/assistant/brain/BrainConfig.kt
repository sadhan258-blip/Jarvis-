package com.jarvis.assistant.brain

data class BrainConfig(
    val providerName: String = "demo",
    val modelName: String = "demo"
)
