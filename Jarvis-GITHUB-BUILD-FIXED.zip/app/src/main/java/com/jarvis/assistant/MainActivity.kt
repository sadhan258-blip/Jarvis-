package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.jarvis.assistant.brain.AiProviderFactory
import com.jarvis.assistant.brain.JarvisBrain
import com.jarvis.assistant.core.BrainCore
import com.jarvis.assistant.core.MemoryStore
import com.jarvis.assistant.core.SecureCredentialStore
import com.jarvis.assistant.voice.JarvisVoiceManager
import kotlinx.coroutines.launch

data class ChatMessage(val id: Long, val user: Boolean, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent { JarvisApp() }
    }
}

@Composable
private fun JarvisApp() {
    val context = LocalContext.current
    val brain = remember { JarvisBrain(AiProviderFactory.create(context)) }
    val controller = remember {
        JarvisController(
            brain = brain,
            core = BrainCore(MemoryStore(context)),
            context = context
        )
    }
    val voice = remember { JarvisVoiceManager(context) }
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(
            listOf(ChatMessage(0L, false, "জার্ভেস প্রস্তুত।"))
        )
    }
    var nextId by remember { mutableLongStateOf(1L) }
    var conversation by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var busy by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var apiKeyInput by remember { mutableStateOf("") }
    val credentialStore = remember { SecureCredentialStore(context) }
    val scope = rememberCoroutineScope()

    fun addMessage(user: Boolean, text: String) {
        messages = messages + ChatMessage(nextId++, user, text)
    }

    fun processText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        addMessage(true, clean)
        input = ""
        scope.launch {
            busy = true
            try {
                controller.process(clean, conversation)
                    .onSuccess {
                        addMessage(false, it)
                        conversation = (conversation + ("user" to clean) + ("assistant" to it)).takeLast(12)
                        voice.speak(it)
                    }
                    .onFailure {
                        val error = it.message?.takeIf { msg -> msg.isNotBlank() }
                            ?: "দুঃখিত, এখন উত্তর তৈরি করা যায়নি।"
                        addMessage(false, error)
                        voice.speak(error)
                    }
            } finally {
                busy = false
            }
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val text = result.data
            ?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!text.isNullOrBlank()) processText(text)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) speechLauncher.launch(voice.recognizerIntent())
        else {
            addMessage(false, "মাইক্রোফোন permission দেওয়া হয়নি।")
        }
    }

    DisposableEffect(Unit) {
        onDispose { voice.release() }
    }

    MaterialTheme {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("JARVIS", style = MaterialTheme.typography.headlineMedium)
                    Text(if (credentialStore.hasApiKey()) "AI key: configured" else "Demo mode", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { apiKeyInput = ""; showSecurityDialog = true }) {
                    Text("Security")
                }
            }
            Text(
                "Voice → Brain → Memory/Action Gate → Voice",
                style = MaterialTheme.typography.bodyMedium
            )

            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    Text(
                        text = if (message.user) "তুমি: ${message.text}"
                        else "জার্ভেস: ${message.text}"
                    )
                }
            }

            if (showSecurityDialog) {
                AlertDialog(
                    onDismissRequest = { showSecurityDialog = false },
                    title = { Text("Jarvis Security") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (credentialStore.hasApiKey()) "API key: configured" else "API key: not configured")
                            OutlinedTextField(
                                value = apiKeyInput,
                                onValueChange = { apiKeyInput = it },
                                label = { Text("New API key") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation()
                            )
                            Text("API key is encrypted with Android Keystore and is never shown after saving.")
                            if (BuildConfig.JARVIS_AI_ENDPOINT.isBlank() || BuildConfig.JARVIS_AI_MODEL.isBlank()) {
                                Text("AI endpoint/model is not configured. Jarvis is currently in safe Demo mode.", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            if (apiKeyInput.isNotBlank() && BuildConfig.JARVIS_AI_ENDPOINT.isNotBlank() && BuildConfig.JARVIS_AI_MODEL.isNotBlank()) {
                                credentialStore.putApiKey(apiKeyInput.trim())
                                brain.setProvider(AiProviderFactory.create(context))
                            }
                            showSecurityDialog = false
                        }) { Text("Save") }
                    },
                    dismissButton = {
                        OutlinedButton(onClick = { credentialStore.clearApiKey(); brain.setProvider(AiProviderFactory.create(context)); showSecurityDialog = false }) {
                            Text("Clear key")
                        }
                    }
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("কথা বলো বা লিখো...") }
                )

                Button(
                    onClick = {
                        val granted = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED

                        if (granted) {
                            speechLauncher.launch(voice.recognizerIntent())
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                ) {
                    Text("🎙")
                }

                Button(onClick = { processText(input) }) {
                    Text("Send")
                }
            }
        }
    }
}
