package com.jarvis.assistant.brain

data class AiRequest(
    val systemPrompt: String,
    val userMessage: String,
    val conversation: List<Pair<String, String>> = emptyList()
)
