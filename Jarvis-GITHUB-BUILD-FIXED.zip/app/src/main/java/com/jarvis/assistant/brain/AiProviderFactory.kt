package com.jarvis.assistant.brain

import android.content.Context
import com.jarvis.assistant.BuildConfig
import com.jarvis.assistant.core.SecureCredentialStore

object AiProviderFactory {
    fun create(context: Context): AiProvider {
        val apiKey = SecureCredentialStore(context).getApiKey()
        val endpoint = BuildConfig.JARVIS_AI_ENDPOINT.trim()
        val model = BuildConfig.JARVIS_AI_MODEL.trim()
        return if (apiKey.isNotBlank() && endpoint.startsWith("https://") && model.isNotBlank()) {
            OpenAiCompatibleProvider(endpoint, apiKey, model)
        } else {
            DemoAiProvider()
        }
    }
}
