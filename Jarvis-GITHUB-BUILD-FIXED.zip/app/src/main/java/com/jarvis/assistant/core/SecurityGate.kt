package com.jarvis.assistant.core

import com.jarvis.assistant.action.ActionRequest

class SecurityGate {
    fun isAllowed(request: ActionRequest): Boolean = when (request) {
        is ActionRequest.OpenSettings,
        is ActionRequest.OpenBrowser,
        is ActionRequest.WebSearch,
        is ActionRequest.OpenMaps,
        is ActionRequest.OpenCalculator,
        is ActionRequest.OpenCamera,
        is ActionRequest.OpenAlarms,
        is ActionRequest.OpenWifiSettings,
        is ActionRequest.OpenBluetoothSettings,
        is ActionRequest.OpenApp -> true
        is ActionRequest.Dial -> request.number.matches(Regex("[+0-9 ()-]{3,25}"))
    }

    fun requiresConfirmation(request: ActionRequest): Boolean = request is ActionRequest.Dial
}
