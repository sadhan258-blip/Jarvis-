package com.jarvis.assistant.action

class ActionParser {
    fun parse(text: String): ActionRequest? {
        val raw = text.trim()
        val normalized = raw.replaceFirst(Regex("(?i)^নিশ্চিত করে\\s+"), "")
        val t = normalized.lowercase()
        return when {
            t.contains("wifi") || t.contains("wi-fi") || t.contains("ওয়াইফাই") || t.contains("ওয়াইফাই") -> ActionRequest.OpenWifiSettings
            t.contains("bluetooth") || t.contains("ব্লুটুথ") -> ActionRequest.OpenBluetoothSettings
            t.contains("camera") || t.contains("ক্যামেরা") -> ActionRequest.OpenCamera
            t.contains("alarm") || t.contains("ঘড়ি") || t.contains("অ্যালার্ম") -> ActionRequest.OpenAlarms
            t.startsWith("search ") || t.startsWith("সার্চ ") || t.startsWith("খুঁজে ") || t.startsWith("খোঁজ ") -> {
                val q = normalized.substringAfter(' ').trim()
                if (q.isNotBlank()) ActionRequest.WebSearch(q) else null
            }
            t.startsWith("map ") || t.startsWith("maps ") || t.startsWith("মানচিত্র ") || t.startsWith("লোকেশন ") -> {
                val q = normalized.substringAfter(' ').trim().ifBlank { null }
                ActionRequest.OpenMaps(q)
            }
            t.contains("settings") || t.contains("সেটিং") || t.contains("সেটিংস") -> ActionRequest.OpenSettings
            t.contains("browser") || t.contains("ব্রাউজার") || t.contains("ইন্টারনেট") -> ActionRequest.OpenBrowser
            t.contains("calculator") || t.contains("ক্যালকুলেটর") -> ActionRequest.OpenCalculator
            t.startsWith("dial ") || t.startsWith("কল ") || t.startsWith("ডায়াল ") || t.startsWith("ডায়াল ") -> {
                val number = normalized.substringAfter(' ').trim()
                if (number.matches(Regex("[+0-9 ()-]{3,25}"))) ActionRequest.Dial(number) else null
            }
            t.contains("youtube") || t.contains("ইউটিউব") -> ActionRequest.OpenApp("com.google.android.youtube", "YouTube")
            t.contains("whatsapp") || t.contains("হোয়াটসঅ্যাপ") || t.contains("হোয়াটসঅ্যাপ") -> ActionRequest.OpenApp("com.whatsapp", "WhatsApp")
            t.contains("telegram") || t.contains("টেলিগ্রাম") -> ActionRequest.OpenApp("org.telegram.messenger", "Telegram")
            t.contains("gmail") || t.contains("জিমেইল") -> ActionRequest.OpenApp("com.google.android.gm", "Gmail")
            else -> null
        }
    }
}
