package com.jarvis.assistant

import android.content.Context
import com.jarvis.assistant.action.ActionParser
import com.jarvis.assistant.action.AndroidActionExecutor
import com.jarvis.assistant.brain.JarvisBrain
import com.jarvis.assistant.core.BrainCore
import com.jarvis.assistant.core.IntentType

class JarvisController(
    private val brain: JarvisBrain,
    private val core: BrainCore,
    context: Context
) {
    private val actionParser = ActionParser()
    private val actionExecutor = AndroidActionExecutor(context.applicationContext)
    suspend fun process(
        text: String,
        conversation: List<Pair<String, String>> = emptyList(),
        confirmed: Boolean = false
    ): Result<String> {
        val coreResult = core.process(text)

        return when (coreResult.intent) {
            IntentType.REMEMBER, IntentType.RECALL ->
                Result.success(coreResult.text)

            IntentType.ACTION -> {
                val request = actionParser.parse(text)
                if (request == null) Result.success(coreResult.text)
                else {
                    val explicitConfirmation = confirmed || text.trim().lowercase().startsWith("নিশ্চিত করে ")
                    if (!explicitConfirmation && request is com.jarvis.assistant.action.ActionRequest.Dial) {
                        Result.success("এই নম্বরে ডায়ালার খুলতে নিশ্চিত করতে বলো: ‘নিশ্চিত করে কল <নম্বর>’।")
                    } else {
                        actionExecutor.execute(request, explicitConfirmation)
                    }
                }
            }

            IntentType.CHAT ->
                brain.think(text, conversation)

            IntentType.UNKNOWN ->
                Result.success(coreResult.text)
        }
    }
}
