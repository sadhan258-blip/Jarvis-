package com.jarvis.assistant.core

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest
import java.util.Locale

/**
 * Creates a non-secret, installation/device-scoped fingerprint used only for
 * local diagnostics and future server-side enrollment. No hardware identifier
 * is sent anywhere by this class.
 */
class DeviceBinding(context: Context) {
    private val appContext = context.applicationContext

    fun fingerprint(): String {
        val androidId = Settings.Secure.getString(
            appContext.contentResolver,
            Settings.Secure.ANDROID_ID
        ).orEmpty()
        val input = "com.jarvis.assistant:$androidId"
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(Locale.US, it) }
    }
}
