package com.jarvis.assistant.brain

interface AiProvider {
    suspend fun generate(request: AiRequest): Result<String>
}
