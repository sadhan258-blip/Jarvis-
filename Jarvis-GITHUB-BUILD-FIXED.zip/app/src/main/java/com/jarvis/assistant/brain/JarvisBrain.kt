package com.jarvis.assistant.brain

class JarvisBrain(private var provider: AiProvider) {
    fun setProvider(provider: AiProvider) { this.provider = provider }
    private val systemPrompt =
        "You are Jarvis, a helpful personal Android assistant. Be clear, honest, and protect user privacy."

    suspend fun think(
        userMessage: String,
        conversation: List<Pair<String, String>> = emptyList()
    ): Result<String> {
        if (userMessage.isBlank()) {
            return Result.failure(IllegalArgumentException("Message is empty"))
        }
        return provider.generate(AiRequest(systemPrompt, userMessage, conversation))
    }
}
