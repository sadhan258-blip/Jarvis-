package com.jarvis.assistant.brain

class DemoAiProvider : AiProvider {
    override suspend fun generate(request: AiRequest): Result<String> =
        Result.success("জার্ভেস ব্রেন সক্রিয়। তুমি বলেছ: “${request.userMessage}”")
}
