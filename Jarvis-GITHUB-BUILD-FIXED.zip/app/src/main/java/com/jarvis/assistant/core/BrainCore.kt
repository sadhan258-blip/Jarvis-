package com.jarvis.assistant.core

enum class IntentType { CHAT, REMEMBER, RECALL, ACTION, UNKNOWN }

data class BrainResponse(
    val text: String,
    val intent: IntentType
)

class BrainCore(
    private val memory: MemoryStore
) {
    fun process(text: String): BrainResponse {
        val t = text.trim()
        val l = t.lowercase()

        return when {
            l.startsWith("মনে রাখ") || l.startsWith("remember") -> {
                val key = t.substringBefore("=")
                    .removePrefix("মনে রাখ")
                    .removePrefix("remember")
                    .trim()
                val value = t.substringAfter("=", "").trim()

                if (key.isNotBlank() && value.isNotBlank()) {
                    memory.remember(key, value)
                    BrainResponse("ঠিক আছে, $key মনে রাখলাম।", IntentType.REMEMBER)
                } else {
                    BrainResponse("এভাবে বলো: মনে রাখ নাম=রাহুল", IntentType.REMEMBER)
                }
            }

            l.startsWith("মনে কর") || l.startsWith("recall") -> {
                val key = t.replaceFirst(Regex("(?i)^মনে কর|^recall"), "").trim()
                BrainResponse(
                    memory.recall(key)?.let { "$key: $it" }
                        ?: "এই তথ্যটি আমার মেমোরিতে নেই।",
                    IntentType.RECALL
                )
            }

            l.startsWith("খুলে দাও") ||
                l.startsWith("open ") ||
                l.startsWith("চালু কর") ||
                l.startsWith("কল ") ||
                l.startsWith("ডায়াল ") ||
                l.startsWith("ডায়াল ") ||
                l.startsWith("dial ") ||
                l.startsWith("search ") ||
                l.startsWith("সার্চ ") ||
                l.startsWith("খুঁজে ") ||
                l.startsWith("map ") ||
                l.startsWith("maps ") ||
                l.startsWith("মানচিত্র ") ||
                l.startsWith("লোকেশন ") ||
                l.contains("camera") || l.contains("ক্যামেরা") ||
                l.contains("calculator") || l.contains("ক্যালকুলেটর") ||
                l.contains("browser") || l.contains("ব্রাউজার") ||
                l.contains("wifi") || l.contains("ওয়াইফাই") || l.contains("ওয়াইফাই") ||
                l.contains("bluetooth") || l.contains("ব্লুটুথ") ||
                l.contains("alarm") || l.contains("অ্যালার্ম") ||
                l.contains("youtube") || l.contains("ইউটিউব") ||
                l.contains("whatsapp") || l.contains("হোয়াটসঅ্যাপ") || l.contains("হোয়াটসঅ্যাপ") ||
                l.contains("telegram") || l.contains("টেলিগ্রাম") ||
                l.contains("gmail") || l.contains("জিমেইল") -> {
                BrainResponse(
                    "এই Android কাজটি Security Gate-এর অনুমোদন নিয়ে চালানো যাবে।",
                    IntentType.ACTION
                )
            }

            t.isNotBlank() -> BrainResponse(t, IntentType.CHAT)
            else -> BrainResponse("কিছু বলো।", IntentType.UNKNOWN)
        }
    }
}
