package com.jarvis.assistant.action

sealed class ActionRequest {
    data object OpenSettings : ActionRequest()
    data object OpenBrowser : ActionRequest()
    data class WebSearch(val query: String) : ActionRequest()
    data class OpenMaps(val query: String?) : ActionRequest()
    data object OpenCalculator : ActionRequest()
    data object OpenCamera : ActionRequest()
    data object OpenAlarms : ActionRequest()
    data object OpenWifiSettings : ActionRequest()
    data object OpenBluetoothSettings : ActionRequest()
    data class OpenApp(val packageName: String, val displayName: String) : ActionRequest()
    data class Dial(val number: String) : ActionRequest()
}
