package com.jarvis.assistant.action

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import com.jarvis.assistant.core.SecurityGate
import java.net.URLEncoder

class AndroidActionExecutor(
    private val context: Context,
    private val gate: SecurityGate = SecurityGate()
) {
    fun execute(request: ActionRequest, confirmed: Boolean = false): Result<String> {
        if (!gate.isAllowed(request)) return Result.failure(SecurityException("Action blocked by Security Gate"))
        if (gate.requiresConfirmation(request) && !confirmed) {
            return Result.failure(SecurityException("Confirmation required before this action"))
        }

        val intent = when (request) {
            ActionRequest.OpenSettings -> Intent(Settings.ACTION_SETTINGS)
            ActionRequest.OpenBrowser -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            is ActionRequest.WebSearch -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${URLEncoder.encode(request.query, "UTF-8")}"))
            is ActionRequest.OpenMaps -> Intent(Intent.ACTION_VIEW, Uri.parse(
                if (request.query.isNullOrBlank()) "geo:0,0?q=" else "geo:0,0?q=${Uri.encode(request.query)}"
            ))
            ActionRequest.OpenCalculator -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
            ActionRequest.OpenCamera -> Intent("android.media.action.IMAGE_CAPTURE")
            ActionRequest.OpenAlarms -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
            ActionRequest.OpenWifiSettings -> Intent(Settings.ACTION_WIFI_SETTINGS)
            ActionRequest.OpenBluetoothSettings -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            is ActionRequest.OpenApp -> context.packageManager.getLaunchIntentForPackage(request.packageName)
                ?: return Result.failure(IllegalStateException("${request.displayName} is not installed"))
            is ActionRequest.Dial -> Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(request.number)}"))
        }

        if (intent.resolveActivity(context.packageManager) == null) {
            return Result.failure(IllegalStateException("এই কাজের জন্য ফোনে কোনো উপযুক্ত অ্যাপ/স্ক্রিন পাওয়া যায়নি।"))
        }

        return runCatching {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            when (request) {
                ActionRequest.OpenSettings -> "সেটিংস খুলে দিয়েছি।"
                ActionRequest.OpenBrowser -> "ব্রাউজার খুলে দিয়েছি।"
                is ActionRequest.WebSearch -> "ওয়েবে ‘${request.query}’ সার্চ খুলে দিয়েছি।"
                is ActionRequest.OpenMaps -> "মানচিত্র খুলে দিয়েছি${request.query?.let { " — $it" } ?: ""}।"
                ActionRequest.OpenCalculator -> "ক্যালকুলেটর খুলে দিয়েছি।"
                ActionRequest.OpenCamera -> "ক্যামেরা খুলে দিয়েছি।"
                ActionRequest.OpenAlarms -> "অ্যালার্ম খুলে দিয়েছি।"
                ActionRequest.OpenWifiSettings -> "Wi‑Fi settings খুলে দিয়েছি।"
                ActionRequest.OpenBluetoothSettings -> "Bluetooth settings খুলে দিয়েছি।"
                is ActionRequest.OpenApp -> "${request.displayName} খুলে দিয়েছি।"
                is ActionRequest.Dial -> "ডায়ালার খুলে নম্বরটি প্রস্তুত করেছি। কল নিজে থেকে করা হয়নি।"
            }
        }
    }
}
