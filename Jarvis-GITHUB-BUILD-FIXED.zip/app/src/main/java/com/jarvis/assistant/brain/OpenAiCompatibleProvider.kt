package com.jarvis.assistant.brain

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI

/** Generic OpenAI-compatible chat-completions provider.
 * The endpoint/model/key are supplied by the build configuration; no secret is hard-coded here.
 */
class OpenAiCompatibleProvider(
    private val endpoint: String,
    private val apiKey: String,
    private val model: String
) : AiProvider {
    override suspend fun generate(request: AiRequest): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val uri = runCatching { URI(endpoint) }.getOrElse { error("AI endpoint is invalid") }
            require(uri.scheme.equals("https", ignoreCase = true)) { "AI endpoint must use HTTPS" }
            require(uri.userInfo == null) { "AI endpoint must not contain embedded credentials" }
            require(!uri.host.isNullOrBlank()) { "AI endpoint must contain a valid host" }
            require(apiKey.isNotBlank()) { "AI API key is not configured" }
            require(model.isNotBlank()) { "AI model is not configured" }

            val messages = JSONArray()
            messages.put(JSONObject().put("role", "system").put("content", request.systemPrompt))
            request.conversation.forEach { (role, content) ->
                messages.put(JSONObject().put("role", role).put("content", content))
            }
            messages.put(JSONObject().put("role", "user").put("content", request.userMessage))

            val body = JSONObject()
                .put("model", model)
                .put("messages", messages)
                .put("temperature", 0.3)

            val connection = (uri.toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("Content-Type", "application/json")
            }

            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText().take(16_384) }.orEmpty()
            connection.disconnect()

            if (code !in 200..299) error("AI provider HTTP $code")

            val json = JSONObject(response)
            json.optJSONArray("choices")?.optJSONObject(0)
                ?.optJSONObject("message")?.optString("content")
                ?.takeIf { it.isNotBlank() }
                ?: error("AI provider returned no message")
        }
    }
}
