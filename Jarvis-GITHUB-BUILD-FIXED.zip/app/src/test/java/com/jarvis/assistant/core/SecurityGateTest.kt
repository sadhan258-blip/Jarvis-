package com.jarvis.assistant.core

import com.jarvis.assistant.action.ActionRequest
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SecurityGateTest {
    private val gate = SecurityGate()

    @Test fun dialRequiresConfirmation() {
        val action = ActionRequest.Dial("+919876543210")
        assertTrue(gate.isAllowed(action))
        assertTrue(gate.requiresConfirmation(action))
    }

    @Test fun malformedDialIsBlocked() {
        assertFalse(gate.isAllowed(ActionRequest.Dial("javascript:alert(1)")))
    }

    @Test fun lowRiskActionsDoNotRequireConfirmation() {
        assertTrue(gate.isAllowed(ActionRequest.OpenSettings))
        assertFalse(gate.requiresConfirmation(ActionRequest.OpenSettings))
    }
}
