package com.jarvis.assistant.action

import org.junit.Assert.assertEquals
import org.junit.Test

class ActionParserTest {
    private val parser = ActionParser()

    @Test fun parsesSettings() {
        assertEquals(ActionRequest.OpenSettings, parser.parse("সেটিংস খুলে দাও"))
    }

    @Test fun parsesDial() {
        assertEquals(ActionRequest.Dial("+919876543210"), parser.parse("কল +919876543210"))
    }

    @Test fun parsesSearch() {
        assertEquals(ActionRequest.WebSearch("কলকাতার আবহাওয়া"), parser.parse("সার্চ কলকাতার আবহাওয়া"))
    }

    @Test fun parsesMaps() {
        assertEquals(ActionRequest.OpenMaps("Jalandhar"), parser.parse("মানচিত্র Jalandhar"))
    }

    @Test fun parsesCommonApps() {
        assertEquals(ActionRequest.OpenApp("com.whatsapp", "WhatsApp"), parser.parse("WhatsApp খুলে দাও"))
    }
}
