This project intentionally uses GitHub Actions' Gradle 8.9 installation.
The repository does not require a locally cached Gradle distribution to build on GitHub.
