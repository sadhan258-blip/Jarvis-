# Jarvis Android SDK Build Setup

Jarvis targets Android SDK 35 and Build Tools 35.0.0. The Android SDK should **not** be copied into this repository or bundled into the ZIP. Keep it installed on the build machine and let Gradle use `ANDROID_SDK_ROOT`/`ANDROID_HOME`.

## Android Studio
1. Install Android Studio from the official Android developer site.
2. Open **Tools > SDK Manager**.
3. Install:
   - Android SDK Platform 35
   - Android SDK Build-Tools 35.0.0
   - Android SDK Platform-Tools
   - Android SDK Command-line Tools (latest)
4. Open this Jarvis folder in Android Studio and sync Gradle.
5. Build with **Build > Generate App Bundles or APKs > Generate APKs**.

## Command line
Set `ANDROID_SDK_ROOT` to the SDK location, then run:

```bash
./tools/setup_android_sdk.sh
./tools/build_release.sh
```

The project already includes a GitHub Actions workflow that provisions JDK 21, Gradle 8.11.1, Android SDK 35, Build Tools 35.0.0, runs validation/tests, and uploads the debug APK.

## Important
A real AI endpoint/model and (for distribution) a release signing keystore are still required. This package does not contain a secret API key.
