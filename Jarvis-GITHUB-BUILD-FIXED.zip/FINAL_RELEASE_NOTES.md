# Jarvis Final Release Notes

## Included hardening
- API key encrypted at rest using Android Keystore + AES-GCM.
- Local Jarvis memory encrypted at rest using a separate Android Keystore key + AES-GCM.
- HTTPS-only AI endpoint enforcement in code.
- Android cleartext traffic disabled.
- No automatic phone calls: dialing opens the system dialer and requires explicit confirmation.
- Runtime microphone permission required before speech recognition.
- App backup disabled.
- No real API secret is included in the repository.
- Security dialog allows the user to enter/replace/clear the API key without exposing the stored key.

## Final device checks required
1. Build with Android SDK/Gradle.
2. Install on a physical Android 8+ device.
3. Test microphone permission and Bengali speech recognition.
4. Test TTS.
5. Test AI request using an HTTPS OpenAI-compatible endpoint.
6. Test settings/browser/calculator actions.
7. Test dial confirmation and verify no automatic call is placed.
8. Verify API key and memory survive app restart but are unavailable after app data is cleared.
9. Verify no HTTP endpoint is accepted.

This package is source-ready; physical-device validation still has to be performed on an actual Android device.

## Extended action set (2026-10-04)
- Web search and maps routing
- Camera, alarms, Wi-Fi and Bluetooth settings intents
- Common app launch routing: YouTube, WhatsApp, Telegram, Gmail
- Dial remains confirmation-gated and uses ACTION_DIAL only
- SecurityGate validates dial input and allow-lists every action

SDK/build setup hardening added on 2026-10-04.
