# Jarvis — GitHub build

1. Put the **contents of this ZIP** in the root of a GitHub repository.
2. Commit the files.
3. Open **Actions** → **Build Jarvis APK**.
4. When the run is green, open the run and download **Jarvis-APK** from **Artifacts**.

Important: GitHub does **not** unpack a ZIP that is merely uploaded as one repository file. The files inside this package must be visible in the repository root, including `.github/workflows/main.yml`.

This package is configured to build a **debug APK**. The CI build is not claimed as completed until GitHub Actions itself shows a successful run.
